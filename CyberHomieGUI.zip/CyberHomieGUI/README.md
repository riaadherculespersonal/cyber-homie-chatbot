# EventEase2 – Final Submission (CLDV6211 POE Part 3)

> Student: **Riaad Hercules**  
> Student Number: **ST10258492**

---

## 📚 Module: Cloud Development A (CLDV6211)  
This repository contains the final submission for Part 3 of the Cloud Development Portfolio of Evidence. The EventEase2 application demonstrates advanced filtering, Azure deployment, and a complete documentation reflection as per the official rubric.

---

## 🚀 Application Overview

EventEase2 is a .NET Core MVC web application that enables:

- 🎟️ Event management (create, edit, delete)
- 🏛️ Venue management with capacity, image, and availability
- 📆 Booking management (user email, event assignment)
- 🔎 Enhanced search with filtering:
  - Event Type
  - Date Range
  - Venue Availability
- ✅ Form validation and user-friendly error handling
- 🌐 Deployment to Azure App Service with Azure SQL Database

---

## 🌐 Live Demo

🔗 **Deployed App:**  
https://eventease2-g3aagcdwevhkcghf.southafricanorth-01.azurewebsites.net/

---

## 🧠 Key Technologies

| Layer | Tools Used |
|-------|-------------|
| Frontend | HTML/CSS, Bootstrap |
| Backend | ASP.NET Core MVC |
| ORM | Entity Framework Core |
| Database | Azure SQL |
| Hosting | Azure Web App |
| Language | C# |

---

## 📂 Folder Structure

├── Controllers/
├── Models/
├── Views/
├── Data/
├── Migrations/
├── wwwroot/
├── appsettings.json
├── Program.cs
├── README.md

---

## 🛠️ Getting Started

> Ensure you have the following installed locally:

- [.NET SDK 7+](https://dotnet.microsoft.com/download)
- Visual Studio 2022 or newer
- Git (for cloning)

```bash
git clone https://github.com/herculesriaadst10258492/EventEase2-FinalPOE-ST10258492.git
cd EventEase2-FinalPOE-ST10258492
dotnet run
📌 Submission Details
GitHub Repository with full source code

Live Azure Deployment

Reflective Technical Report (in /docs or Word format)

Code logic reflection, screenshots, and testing matrix included

📄 License & Attribution
This repository is for academic assessment purposes only.
All external libraries and tools used are properly attributed.


